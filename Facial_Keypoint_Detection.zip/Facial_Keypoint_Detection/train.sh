nohup  python train.py --epochs 100 --sub_epoch 25 > ./res/100_25.txt 2>&1
nohup  python train.py --epochs 100  --sub_epoch 50 > ./res/100_50.txt 2>&1
nohup  python train.py --epochs 100 --sub_epoch 75 > ./res/100_75.txt 2>&1
nohup  python train.py --epochs 100 > ./res/100.txt 2>&1