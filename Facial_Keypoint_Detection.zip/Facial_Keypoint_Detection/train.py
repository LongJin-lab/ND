# %%
from znd import ZNDOptimizer
import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import transforms

from data_load import FacialKeypointsDataset
from data_load import Rescale, RandomCrop, Normalize, ToTensor
from models import *

# nd_random
from random_noise.znd_random import ZNDRandom
# momentum_random
from random_noise.momentum_random import MomentumRandom
# adam_random
from random_noise.adam_random import AdamRandom

#nd_constant
from constant_noise.znd_constant import ZNDConstant
#momentum_constant
from constant_noise.momentum_constant import MomentumConstant
#adam_constant
from constant_noise.adam_constant import AdamConstant


os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

# from models import Net
# from preact_resnet import FP_PreActResNet34
# from T2_ResNetV2 import FP_T22ResNet36

# from Taylor import Taylor
I = 3
I = float(I)

parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--sub_epoch', default=0, type=int)
parser.add_argument('--epochs', default=20, type=int)
parser.add_argument('--lr', default=0.1, type=float)
args = parser.parse_args()

# arch = "fppr34"

device = 'cuda' if torch.cuda.is_available() else 'cpu'

# net = resnet()
net = resnet18()
# net = resnet34()
# net = inceptionv3()
# net = mobilenet()


# if arch == "fppr34" :
#     net = FP_PreActResNet34()
# elif arch == "fpt2236":
#     net = FP_T22ResNet36()
# elif arch == "a":
#     net = Net()

if device == 'cuda':
    net = torch.nn.DataParallel(net)
    cudnn.benchmark = True
net.to(device)

data_transform = transforms.Compose([Rescale(250),
                                     RandomCrop(224),
                                     Normalize(),
                                     ToTensor()])

# testing that you've defined a transform
assert (data_transform is not None), 'Define a data_transform'

# create the transformed dataset
transformed_dataset = FacialKeypointsDataset(csv_file='./data/training_frames_keypoints.csv',
                                             root_dir='./data/training/', transform=data_transform)

print('Number of images: ', len(transformed_dataset))

# iterate through the transformed dataset and print some stats about the first few samples
for i in range(4):
    sample = transformed_dataset[i]
    print(i, sample['image'].size(), sample['keypoints'].size())

batch_size = 10

train_loader = DataLoader(transformed_dataset,
                          batch_size=batch_size,
                          shuffle=True,
                          num_workers=0)

test_dataset = FacialKeypointsDataset(csv_file='./data/test_frames_keypoints.csv', root_dir='./data/test/',
                                      transform=data_transform)

test_loader = DataLoader(test_dataset,
                         batch_size=batch_size,
                         shuffle=True,
                         num_workers=0)


def net_sample_output():
    # iterate through the test dataset
    for i, sample in enumerate(test_loader):

        # get sample data: images and ground truth keypoints
        images = sample['image']
        key_pts = sample['keypoints']

        # convert images to FloatTensors
        images = images.type(torch.FloatTensor)

        # forward pass to get net output
        output_pts = net(images)

        # reshape to batch_size x 68 x 2 pts
        output_pts = output_pts.view(output_pts.size()[0], 68, -1)

        # break after first image is tested
        if i == 0:
            return images, output_pts, key_pts


def show_all_keypoints(image, predicted_key_pts, gt_pts=None):
    """Show image with predicted keypoints"""
    # image is grayscale
    plt.imshow(image, cmap='gray')
    plt.scatter(predicted_key_pts[:, 0],
                predicted_key_pts[:, 1], s=20, marker='.', c='m')
    # plot ground truth points as green pts
    if gt_pts is not None:
        plt.scatter(gt_pts[:, 0], gt_pts[:, 1], s=20, marker='.', c='g')


def visualize_output(test_images, test_outputs, gt_pts=None, batch_size=10):
    for i in range(batch_size):
        plt.figure(figsize=(20, 10))
        ax = plt.subplot(1, batch_size, i + 1)

        # un-transform the image data
        image = test_images[i].data  # get the image from it's Variable wrapper
        image = image.numpy()  # convert to numpy array from a Tensor
        # transpose to go from torch to numpy image
        image = np.transpose(image, (1, 2, 0))

        # un-transform the predicted key_pts data
        predicted_key_pts = test_outputs[i].data
        predicted_key_pts = predicted_key_pts.numpy()
        # undo normalization of keypoints
        predicted_key_pts = predicted_key_pts * 50.0 + 100

        # plot ground truth points for comparison, if they exist
        ground_truth_pts = None
        if gt_pts is not None:
            ground_truth_pts = gt_pts[i]
            ground_truth_pts = ground_truth_pts * 50.0 + 100

        # call show_all_keypoints
        show_all_keypoints(np.squeeze(
            image), predicted_key_pts, ground_truth_pts)

        plt.axis('off')

    plt.show()


# %%
criterion = nn.SmoothL1Loss()

optimizer = optim.SGD(net.parameters(), lr = 0.001)

# optimizer = optim.Adam(net.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=5e-4)
# optimizer = ZNDOptimizer(net.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4, I=I)
# optimizer = optim.SGD(net.parameters(), lr=0.001, weight_decay=5e-4, momentum=0.9)

## constant noise
# optimizer = AdamConstant(net.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=5e-4)
# optimizer = MomentumConstant(net.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)
# optimizer = ZNDConstant(net.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4, I = I)
## random noise
# optimizer = MomentumRandom(net.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)
# optimizer = ZNDRandom(net.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)
# optimizer = AdamRandom(net.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=5e-4)


def train_net(n_epochs):
    loss_ = []
    # prepare the net for training
    net.train()

    for epoch in range(n_epochs):  # loop over the dataset multiple times
        loss_sum = 0.0
        running_loss = 0.0

        # train on batches of data, assumes you already have train_loader
        for batch_i, data in enumerate(train_loader):
            # get the input images and their corresponding labels
            images = data['image']
            key_pts = data['keypoints']

            # flatten pts
            key_pts = key_pts.view(key_pts.size(0), -1)

            # convert variables to floats for regression loss
            key_pts = key_pts.type(torch.FloatTensor)
            images = images.type(torch.FloatTensor)
            images = images.to(device)
            key_pts = key_pts.to(device)
            key_pts = key_pts.to(device)

            # forward pass to get outputs
            output_pts = net(images)

            # calculate the loss between predicted and target keypoints
            loss = criterion(output_pts, key_pts)

            # zero the parameter (weight) gradients
            optimizer.zero_grad()

            # backward pass to calculate the weight gradients
            loss.backward()

            # update the weights
            # optimizer.step()
            if args.sub_epoch != 0:
                optimizer.step(epoch, args.sub_epoch, batch_i)
            else:
                optimizer.step()

            # print loss statistics
            running_loss += loss.item()
            if batch_i % 10 == 9:  # print every 10 batches
                print('Epoch: {}, Batch: {}, Avg. Loss: {}'.format(
                    epoch + 1, batch_i + 1, running_loss / 10))
                loss_.append(running_loss / 10)
                running_loss = 0.0
            loss_sum += loss.item()
    print("epoch:{}, loss:{}".format(epoch, loss_sum / batch_i))

    print('Finished Training')

    return loss_


n_epochs = args.epochs
a = train_net(n_epochs)
# print(a)
print("%.5f" % np.mean(a))
print("%.5f" % np.var(a))

# # %%
# test_images, test_outputs, gt_pts = net_sample_output()
# visualize_output(test_images, test_outputs.cpu(), gt_pts)

# #%%
# model_dir = './saved_models/'
# model_name = arch + '.pt'

# # after training, save your model parameters in the dir 'saved_models'
# torch.save(net.state_dict(), model_dir+model_name)

# %%
